# Solar System Explorer

## Overview

This is an interactive 3D Solar System visualization application built with React Three Fiber. Users can explore the solar system with clickable planets that display educational information, adjustable animation speeds, and interactive camera controls. The application features a realistic representation of the sun, eight planets with their moons, an asteroid belt, and a beautiful starfield background.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Core Framework**: React with TypeScript, using Vite as the build tool and development server.

**3D Graphics**: React Three Fiber (@react-three/fiber) serves as the primary 3D rendering engine, providing a React wrapper around Three.js. Additional utilities from @react-three/drei handle common 3D patterns like OrbitControls and HTML overlays. The application includes support for GLSL shaders via vite-plugin-glsl.

**State Management**: Zustand is used for all global state management with three main stores:
- `useSolarSystem` - Controls animation speed, pause state, and educational mode
- `usePlanetSelection` - Manages which planet is currently selected for detailed viewing
- `useGame` and `useAudio` - Additional stores present but not actively used in the main solar system feature

**UI Components**: Radix UI primitives provide accessible, unstyled component foundations (dialogs, buttons, sliders, switches, etc.). Tailwind CSS handles styling with a custom configuration that includes CSS variables for theming. The design system uses shadcn/ui patterns with components in `client/src/components/ui/`.

**Styling Approach**: Tailwind CSS with PostCSS processing and a custom theme configuration. Uses CSS variables for dynamic theming (background, foreground, primary, secondary, etc.). The `cn()` utility function from class-variance-authority merges Tailwind classes intelligently.

### Backend Architecture

**Server Framework**: Express.js with TypeScript, configured as an ES module.

**Development Setup**: Custom Vite middleware integration allows the Express server to serve the Vite development server in development mode, with production builds serving static assets. The server logs API requests with timing information.

**API Structure**: Routes are registered through a `registerRoutes` function in `server/routes.ts`. Currently minimal, designed to be extended with API endpoints prefixed with `/api`.

**Storage Layer**: Abstract storage interface (`IStorage`) with an in-memory implementation (`MemStorage`). Designed to be swapped with a database-backed implementation. Currently provides basic user CRUD operations.

### Data Storage Solutions

**Database ORM**: Drizzle ORM configured for PostgreSQL (via @neondatabase/serverless), with schema definitions in `shared/schema.ts`. The current schema includes a users table with username/password fields.

**Migration Strategy**: Drizzle Kit manages migrations with output to `./migrations` directory. Uses `drizzle-kit push` for schema changes.

**Validation**: Zod schemas generated from Drizzle schemas using `drizzle-zod` for runtime type validation.

**Current Implementation**: In-memory storage is active for development. The architecture supports switching to PostgreSQL without changing the storage interface contracts.

### Design Patterns

**Separation of Concerns**: Clear separation between client (React), server (Express), and shared code (schemas, types). Path aliases (`@/*` for client, `@shared/*` for shared) enable clean imports.

**Component Composition**: 3D scene built from composable components (Planet, Moon, StarField, AsteroidBelt) that manage their own animation loops via `useFrame` hooks.

**Ref-Based Animation**: Uses React refs to access Three.js objects directly for performance-critical animation updates within `useFrame` callbacks.

**Store-Based Configuration**: Animation parameters and UI state live in Zustand stores, allowing components to react to changes without prop drilling.

## External Dependencies

### Third-Party Services

**Neon Database**: PostgreSQL serverless database (@neondatabase/serverless) configured via `DATABASE_URL` environment variable. Used with Drizzle ORM for data persistence.

### UI Libraries

**Radix UI**: Comprehensive set of accessible, unstyled React components including accordions, dialogs, dropdowns, popovers, sliders, switches, and tabs.

**Tailwind CSS**: Utility-first CSS framework with custom configuration for the design system.

**Fontsource**: Self-hosted Inter font family (@fontsource/inter).

### 3D Graphics Stack

**Three.js**: Core 3D graphics library (via React Three Fiber wrapper).

**@react-three/fiber**: React renderer for Three.js enabling declarative 3D scenes.

**@react-three/drei**: Helper components and abstractions for common Three.js patterns (OrbitControls, Html, etc.).

**@react-three/postprocessing**: Post-processing effects (currently imported but not actively used).

### State and Data Management

**Zustand**: Lightweight state management with middleware support (subscribeWithSelector).

**TanStack Query**: Data fetching and caching library (@tanstack/react-query) with custom query client configuration.

**React Hook Form**: Form state management (imported in UI components).

**Zod**: Schema validation library for runtime type checking.

### Development Tools

**Vite**: Build tool and development server with React plugin and custom runtime error overlay (@replit/vite-plugin-runtime-error-modal).

**TypeScript**: Type safety across the entire codebase with strict mode enabled.

**Drizzle Kit**: Database migration tool for Drizzle ORM.

**esbuild**: Fast bundler used for production server builds.