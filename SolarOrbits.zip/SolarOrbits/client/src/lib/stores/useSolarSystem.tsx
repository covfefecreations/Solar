import { create } from 'zustand';

interface SolarSystemState {
  animationSpeed: number;
  isPaused: boolean;
  educationalMode: boolean;
  setAnimationSpeed: (speed: number) => void;
  togglePause: () => void;
  toggleEducationalMode: () => void;
}

export const useSolarSystem = create<SolarSystemState>((set) => ({
  animationSpeed: 1.0,
  isPaused: false,
  educationalMode: false,
  setAnimationSpeed: (speed) => set({ animationSpeed: speed }),
  togglePause: () => set((state) => ({ isPaused: !state.isPaused })),
  toggleEducationalMode: () => set((state) => ({ educationalMode: !state.educationalMode })),
}));
