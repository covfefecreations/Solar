import { create } from 'zustand';
import { PlanetInfo } from "../data/planetData";

interface PlanetSelectionState {
  selectedPlanet: PlanetInfo | null;
  selectPlanet: (planet: PlanetInfo) => void;
  clearSelection: () => void;
}

export const usePlanetSelection = create<PlanetSelectionState>((set) => ({
  selectedPlanet: null,
  selectPlanet: (planet) => set({ selectedPlanet: planet }),
  clearSelection: () => set({ selectedPlanet: null }),
}));
