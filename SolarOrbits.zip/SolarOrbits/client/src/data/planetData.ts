export interface MoonInfo {
  name: string;
  size: number;
  distance: number;
  orbitSpeed: number;
  color: string;
}

export interface PlanetInfo {
  name: string;
  size: number;
  distance: number;
  orbitSpeed: number;
  rotationSpeed: number;
  color: string;
  emissive?: string;
  diameter: string;
  distanceFromSun: string;
  orbitalPeriod: string;
  rotationPeriod: string;
  moons: number;
  composition: string;
  atmosphere: string;
  funFact: string;
  temperature: string;
  moonList?: MoonInfo[];
}

export const planetData = {
  sun: {
    name: "Sun",
    size: 5,
    distance: 0,
    orbitSpeed: 0,
    rotationSpeed: 0.1,
    color: "#FDB813",
    emissive: "#FDB813",
    diameter: "1,392,700 km",
    distanceFromSun: "0 km (center)",
    orbitalPeriod: "N/A",
    rotationPeriod: "25-35 days",
    moons: 0,
    composition: "73% Hydrogen, 25% Helium, 2% heavier elements",
    atmosphere: "Corona of superheated plasma",
    temperature: "5,778 K surface, 15 million K core",
    funFact: "The Sun is so massive that it accounts for 99.86% of the total mass of our Solar System!"
  },
  
  planets: {
    mercury: {
      name: "Mercury",
      size: 0.8,
      distance: 15,
      orbitSpeed: 1.6,
      rotationSpeed: 0.02,
      color: "#8C7853",
      diameter: "4,879 km",
      distanceFromSun: "57.9 million km",
      orbitalPeriod: "88 Earth days",
      rotationPeriod: "59 Earth days",
      moons: 0,
      composition: "Large iron core, thin silicate mantle",
      atmosphere: "Extremely thin exosphere",
      temperature: "-173°C to 427°C",
      funFact: "Mercury has the most eccentric orbit of all planets and experiences extreme temperature variations!"
    },
    
    venus: {
      name: "Venus",
      size: 1.2,
      distance: 22,
      orbitSpeed: 1.2,
      rotationSpeed: -0.006,
      color: "#FFC649",
      diameter: "12,104 km",
      distanceFromSun: "108.2 million km",
      orbitalPeriod: "225 Earth days",
      rotationPeriod: "243 Earth days (retrograde)",
      moons: 0,
      composition: "Iron core, rocky mantle, thick crust",
      atmosphere: "96% CO2, dense sulfuric acid clouds",
      temperature: "462°C average",
      funFact: "Venus rotates backwards and a day on Venus is longer than its year!"
    },
    
    earth: {
      name: "Earth",
      size: 1.3,
      distance: 30,
      orbitSpeed: 1.0,
      rotationSpeed: 1.0,
      color: "#4F94CD",
      emissive: "#001133",
      diameter: "12,756 km",
      distanceFromSun: "149.6 million km",
      orbitalPeriod: "365.25 days",
      rotationPeriod: "24 hours",
      moons: 1,
      composition: "Iron core, silicate mantle and crust",
      atmosphere: "78% Nitrogen, 21% Oxygen",
      temperature: "15°C average",
      funFact: "Earth is the only known planet with life and liquid water on its surface!",
      moonList: [
        { name: "Moon", size: 0.35, distance: 3, orbitSpeed: 1.0, color: "#C0C0C0" }
      ]
    },
    
    mars: {
      name: "Mars",
      size: 1.0,
      distance: 45,
      orbitSpeed: 0.8,
      rotationSpeed: 0.97,
      color: "#CD5C5C",
      diameter: "6,792 km",
      distanceFromSun: "227.9 million km",
      orbitalPeriod: "687 Earth days",
      rotationPeriod: "24.6 hours",
      moons: 2,
      composition: "Iron core, basaltic rock mantle and crust",
      atmosphere: "95% CO2, very thin",
      temperature: "-87°C to -5°C",
      funFact: "Mars has the largest volcano in the solar system, Olympus Mons, which is 21 km high!"
    },
    
    jupiter: {
      name: "Jupiter",
      size: 3.5,
      distance: 70,
      orbitSpeed: 0.4,
      rotationSpeed: 2.4,
      color: "#D8CA9D",
      diameter: "142,984 km",
      distanceFromSun: "778.5 million km",
      orbitalPeriod: "11.9 Earth years",
      rotationPeriod: "9.9 hours",
      moons: 95,
      composition: "Gas giant: 90% Hydrogen, 10% Helium",
      atmosphere: "Hydrogen and helium with trace compounds",
      temperature: "-108°C average",
      funFact: "Jupiter is so massive it could fit all other planets inside it and still have room to spare!",
      moonList: [
        { name: "Io", size: 0.36, distance: 5, orbitSpeed: 2.5, color: "#F4D03F" },
        { name: "Europa", size: 0.31, distance: 7, orbitSpeed: 2.0, color: "#E8DCC8" },
        { name: "Ganymede", size: 0.41, distance: 9, orbitSpeed: 1.5, color: "#B8B8B8" },
        { name: "Callisto", size: 0.38, distance: 11, orbitSpeed: 1.2, color: "#8B7D6B" }
      ]
    },
    
    saturn: {
      name: "Saturn",
      size: 3.0,
      distance: 95,
      orbitSpeed: 0.32,
      rotationSpeed: 2.2,
      color: "#FAD5A5",
      diameter: "120,536 km",
      distanceFromSun: "1.43 billion km",
      orbitalPeriod: "29.5 Earth years",
      rotationPeriod: "10.7 hours",
      moons: 146,
      composition: "Gas giant: similar to Jupiter",
      atmosphere: "Hydrogen and helium",
      temperature: "-139°C average",
      funFact: "Saturn's density is so low that it would float in water if you could find a bathtub big enough!",
      moonList: [
        { name: "Titan", size: 0.40, distance: 9, orbitSpeed: 1.8, color: "#E5B57A" },
        { name: "Rhea", size: 0.15, distance: 6, orbitSpeed: 2.2, color: "#D3D3D3" },
        { name: "Iapetus", size: 0.14, distance: 12, orbitSpeed: 1.3, color: "#8B8378" }
      ]
    },
    
    uranus: {
      name: "Uranus",
      size: 2.0,
      distance: 130,
      orbitSpeed: 0.23,
      rotationSpeed: 1.4,
      color: "#4FD0E7",
      diameter: "51,118 km",
      distanceFromSun: "2.87 billion km",
      orbitalPeriod: "84 Earth years",
      rotationPeriod: "17.2 hours",
      moons: 27,
      composition: "Ice giant: water, methane, ammonia ices",
      atmosphere: "83% Hydrogen, 15% Helium, 2% Methane",
      temperature: "-197°C average",
      funFact: "Uranus rotates on its side with an axial tilt of 98 degrees, possibly due to an ancient collision!"
    },
    
    neptune: {
      name: "Neptune",
      size: 1.9,
      distance: 165,
      orbitSpeed: 0.18,
      rotationSpeed: 1.5,
      color: "#4169E1",
      diameter: "49,528 km",
      distanceFromSun: "4.50 billion km",
      orbitalPeriod: "165 Earth years",
      rotationPeriod: "16.1 hours",
      moons: 16,
      composition: "Ice giant: similar to Uranus",
      atmosphere: "80% Hydrogen, 19% Helium, 1% Methane",
      temperature: "-201°C average",
      funFact: "Neptune has the strongest winds in the solar system, reaching speeds of up to 2,100 km/h!"
    }
  }
};
