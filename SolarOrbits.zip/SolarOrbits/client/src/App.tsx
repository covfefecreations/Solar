import { Canvas } from "@react-three/fiber";
import { Suspense, useState, useEffect } from "react";
import { OrbitControls } from "@react-three/drei";
import "@fontsource/inter";
import SolarSystem, { SolarSystemUI } from "./components/SolarSystem";
import "./index.css";

function WebGLFallback() {
  return (
    <div style={{
      width: '100vw',
      height: '100vh',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: 'linear-gradient(to bottom, #000428, #004e92)',
      color: 'white',
      fontFamily: 'Inter, system-ui, sans-serif'
    }}>
      <div style={{
        maxWidth: '600px',
        padding: '40px',
        textAlign: 'center',
        background: 'rgba(0, 0, 0, 0.5)',
        borderRadius: '20px',
        border: '1px solid rgba(255, 255, 255, 0.1)'
      }}>
        <h1 style={{ fontSize: '2.5em', marginBottom: '20px', color: '#4fd0e7' }}>
          🌌 Solar System Explorer
        </h1>
        <p style={{ fontSize: '1.2em', lineHeight: '1.6', marginBottom: '30px' }}>
          This interactive 3D visualization requires WebGL support to render the solar system.
        </p>
        <div style={{
          background: 'rgba(255, 255, 255, 0.05)',
          padding: '20px',
          borderRadius: '10px',
          marginBottom: '20px'
        }}>
          <p style={{ fontSize: '1em', lineHeight: '1.6', color: '#aaa' }}>
            Your browser or environment doesn't support WebGL, which is needed for 3D graphics.
            Try opening this application in a modern browser like Chrome, Firefox, or Safari.
          </p>
        </div>
        <div style={{ fontSize: '0.9em', color: '#888' }}>
          <p>The solar system includes:</p>
          <p>☀️ The Sun and 8 planets</p>
          <p>🪐 Clickable planets with educational facts</p>
          <p>🎮 Interactive camera controls</p>
          <p>⭐ Beautiful space environment</p>
        </div>
      </div>
    </div>
  );
}

function App() {
  const [webglSupported, setWebglSupported] = useState<boolean | null>(null);
  const [renderError, setRenderError] = useState(false);

  useEffect(() => {
    // Check WebGL support
    try {
      const canvas = document.createElement('canvas');
      const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
      setWebglSupported(!!gl);
    } catch (e) {
      setWebglSupported(false);
    }
  }, []);

  // Show loading while checking WebGL
  if (webglSupported === null) {
    return (
      <div style={{
        width: '100vw',
        height: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        background: '#000',
        color: 'white',
        fontFamily: 'Inter, system-ui, sans-serif'
      }}>
        <div style={{ textAlign: 'center' }}>
          <h2 style={{ fontSize: '1.5em', color: '#4fd0e7' }}>Loading Solar System...</h2>
        </div>
      </div>
    );
  }

  // Show fallback if WebGL not supported or render error occurred
  if (!webglSupported || renderError) {
    return <WebGLFallback />;
  }

  return (
    <div style={{ width: '100vw', height: '100vh', position: 'relative', overflow: 'hidden', background: '#000' }}>
      <Canvas
        camera={{
          position: [0, 50, 100],
          fov: 60,
          near: 0.1,
          far: 2000
        }}
        gl={{
          antialias: true,
          powerPreference: "high-performance"
        }}
        onCreated={(state) => {
          console.log('WebGL context created successfully');
        }}
        onError={(error) => {
          console.error('Canvas error:', error);
          setRenderError(true);
        }}
      >
        <color attach="background" args={["#000011"]} />
        
        {/* Lighting */}
        <ambientLight intensity={0.1} />
        <pointLight 
          position={[0, 0, 0]} 
          intensity={2} 
          color="#ffffff"
          distance={0}
          decay={2}
        />
        
        <Suspense fallback={null}>
          <SolarSystem />
        </Suspense>
        
        <OrbitControls 
          enablePan={true}
          enableZoom={true}
          enableRotate={true}
          minDistance={20}
          maxDistance={500}
          autoRotate={false}
        />
      </Canvas>
      
      {/* UI overlay outside Canvas */}
      <SolarSystemUI />
    </div>
  );
}

export default App;
