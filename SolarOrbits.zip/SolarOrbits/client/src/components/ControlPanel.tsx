import { Button } from "./ui/button";
import { Card, CardContent } from "./ui/card";
import { Slider } from "./ui/slider";
import { Switch } from "./ui/switch";
import { Label } from "./ui/label";
import { Play, Pause, Info } from "lucide-react";
import { useSolarSystem } from "../lib/stores/useSolarSystem";

export default function ControlPanel() {
  const { 
    animationSpeed, 
    isPaused, 
    educationalMode,
    setAnimationSpeed, 
    togglePause, 
    toggleEducationalMode 
  } = useSolarSystem();

  return (
    <div className="fixed bottom-4 left-4 z-50">
      <Card className="bg-gray-900 border-gray-700 text-white shadow-2xl">
        <CardContent className="p-4 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold text-blue-300">Controls</h3>
            <Button
              variant="ghost"
              size="sm"
              onClick={togglePause}
              className="text-white hover:bg-gray-800"
            >
              {isPaused ? <Play className="h-5 w-5" /> : <Pause className="h-5 w-5" />}
            </Button>
          </div>

          <div className="space-y-2">
            <Label className="text-gray-300 text-sm">Animation Speed: {animationSpeed.toFixed(1)}x</Label>
            <Slider
              value={[animationSpeed]}
              onValueChange={(value) => setAnimationSpeed(value[0])}
              min={0.1}
              max={5}
              step={0.1}
              className="w-48"
            />
          </div>

          <div className="flex items-center space-x-2">
            <Switch
              id="educational-mode"
              checked={educationalMode}
              onCheckedChange={toggleEducationalMode}
            />
            <Label htmlFor="educational-mode" className="text-gray-300 text-sm flex items-center gap-2">
              <Info className="h-4 w-4" />
              Educational Mode
            </Label>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
