import { useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { MoonInfo } from "../data/planetData";
import { useSolarSystem } from "../lib/stores/useSolarSystem";

interface MoonProps {
  moonData: MoonInfo;
}

export default function Moon({ moonData }: MoonProps) {
  const meshRef = useRef<THREE.Mesh>(null);
  const orbitRef = useRef<THREE.Group>(null);
  const { animationSpeed, isPaused } = useSolarSystem();

  useFrame((state, delta) => {
    if (isPaused) return;
    
    const adjustedDelta = delta * animationSpeed;
    
    if (orbitRef.current) {
      orbitRef.current.rotation.y += adjustedDelta * moonData.orbitSpeed;
    }
  });

  return (
    <group ref={orbitRef}>
      <mesh ref={meshRef} position={[moonData.distance, 0, 0]}>
        <sphereGeometry args={[moonData.size, 8, 8]} />
        <meshLambertMaterial color={moonData.color} />
      </mesh>
    </group>
  );
}
