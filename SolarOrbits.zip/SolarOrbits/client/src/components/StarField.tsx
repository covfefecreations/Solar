import { useMemo } from "react";
import * as THREE from "three";

export default function StarField() {
  const stars = useMemo(() => {
    const starGeometry = new THREE.BufferGeometry();
    const starCount = 1000;
    const positions = new Float32Array(starCount * 3);
    
    for (let i = 0; i < starCount * 3; i += 3) {
      // Create stars in a sphere around the solar system
      const radius = 800 + Math.random() * 400;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.random() * Math.PI;
      
      positions[i] = radius * Math.sin(phi) * Math.cos(theta);     // x
      positions[i + 1] = radius * Math.sin(phi) * Math.sin(theta); // y
      positions[i + 2] = radius * Math.cos(phi);                   // z
    }
    
    starGeometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    return starGeometry;
  }, []);

  return (
    <points geometry={stars}>
      <pointsMaterial
        color="#ffffff"
        size={2}
        transparent
        opacity={0.8}
        sizeAttenuation={true}
      />
    </points>
  );
}
