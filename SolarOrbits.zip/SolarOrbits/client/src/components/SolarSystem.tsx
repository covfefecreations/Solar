import { useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import Planet from "./Planet";
import StarField from "./StarField";
import PlanetInfoPanel from "./PlanetInfoPanel";
import AsteroidBelt from "./AsteroidBelt";
import ControlPanel from "./ControlPanel";
import PlanetLabel from "./PlanetLabel";
import { planetData } from "../data/planetData";
import { usePlanetSelection } from "../hooks/usePlanetSelection";
import { useSolarSystem } from "../lib/stores/useSolarSystem";

export default function SolarSystem() {
  const groupRef = useRef<THREE.Group>(null);
  const { selectedPlanet, selectPlanet, clearSelection } = usePlanetSelection();
  const { animationSpeed, isPaused, educationalMode } = useSolarSystem();

  // Rotate the entire solar system slowly
  useFrame((state, delta) => {
    if (isPaused) return;
    
    const adjustedDelta = delta * animationSpeed;
    
    if (groupRef.current) {
      groupRef.current.rotation.y += adjustedDelta * 0.05;
    }
  });

  return (
    <>
      <StarField />
      
      <group ref={groupRef}>
        {/* Sun */}
        <mesh position={[0, 0, 0]} onClick={() => selectPlanet(planetData.sun)}>
          <sphereGeometry args={[5, 32, 32]} />
          <meshBasicMaterial 
            color="#FDB813"
          />
        </mesh>
        
        {/* Sun glow effect */}
        <mesh position={[0, 0, 0]}>
          <sphereGeometry args={[7, 32, 32]} />
          <meshBasicMaterial 
            color="#FDB813" 
            transparent 
            opacity={0.1}
          />
        </mesh>

        {/* Sun label in educational mode */}
        {educationalMode && (
          <PlanetLabel 
            name="Sun" 
            position={[0, 7, 0]} 
          />
        )}

        {/* Asteroid Belt */}
        <AsteroidBelt />

        {/* Planets */}
        {Object.entries(planetData.planets).map(([key, planet]) => (
          <Planet
            key={key}
            planetData={planet}
            isSelected={selectedPlanet?.name === planet.name}
            onSelect={() => selectPlanet(planet)}
          />
        ))}
      </group>

      {/* UI (outside Canvas) - added to parent */}
    </>
  );
}

// Export the UI components separately to be rendered outside Canvas
export function SolarSystemUI() {
  const { selectedPlanet, clearSelection } = usePlanetSelection();
  
  return (
    <>
      <ControlPanel />
      
      {selectedPlanet && (
        <PlanetInfoPanel 
          planet={selectedPlanet} 
          onClose={clearSelection}
        />
      )}
    </>
  );
}
