import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { X } from "lucide-react";

interface PlanetInfo {
  name: string;
  diameter: string;
  distanceFromSun: string;
  orbitalPeriod: string;
  rotationPeriod: string;
  moons: number;
  composition: string;
  atmosphere: string;
  funFact: string;
  temperature: string;
}

interface PlanetInfoPanelProps {
  planet: PlanetInfo;
  onClose: () => void;
}

export default function PlanetInfoPanel({ planet, onClose }: PlanetInfoPanelProps) {
  return (
    <div className="fixed top-4 right-4 z-50 max-w-md">
      <Card className="bg-gray-900 border-gray-700 text-white shadow-2xl">
        <CardHeader className="pb-4">
          <div className="flex justify-between items-center">
            <CardTitle className="text-2xl font-bold text-blue-300">
              {planet.name}
            </CardTitle>
            <Button 
              variant="ghost" 
              size="sm"
              onClick={onClose}
              className="text-gray-400 hover:text-white"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </CardHeader>
        
        <CardContent className="space-y-3 text-sm">
          <div className="grid grid-cols-1 gap-3">
            <InfoItem label="Diameter" value={planet.diameter} />
            <InfoItem label="Distance from Sun" value={planet.distanceFromSun} />
            <InfoItem label="Orbital Period" value={planet.orbitalPeriod} />
            <InfoItem label="Rotation Period" value={planet.rotationPeriod} />
            <InfoItem label="Temperature" value={planet.temperature} />
            <InfoItem label="Moons" value={planet.moons.toString()} />
            <InfoItem label="Composition" value={planet.composition} />
            <InfoItem label="Atmosphere" value={planet.atmosphere} />
          </div>
          
          <div className="mt-4 p-3 bg-blue-900 rounded-lg">
            <h4 className="font-semibold text-blue-200 mb-2">Fun Fact</h4>
            <p className="text-blue-100 text-xs leading-relaxed">
              {planet.funFact}
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function InfoItem({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between items-start">
      <span className="text-gray-400 font-medium">{label}:</span>
      <span className="text-white text-right flex-1 ml-2">{value}</span>
    </div>
  );
}
