import { Html } from "@react-three/drei";

interface PlanetLabelProps {
  name: string;
  position: [number, number, number];
}

export default function PlanetLabel({ name, position }: PlanetLabelProps) {
  return (
    <Html position={position} center distanceFactor={10}>
      <div className="bg-gray-900 bg-opacity-80 text-white px-2 py-1 rounded text-xs font-semibold border border-blue-500 whitespace-nowrap pointer-events-none">
        {name}
      </div>
    </Html>
  );
}
