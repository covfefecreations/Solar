import { useMemo } from "react";
import * as THREE from "three";

export default function AsteroidBelt() {
  const asteroids = useMemo(() => {
    const positions: number[] = [];
    const asteroidCount = 300;
    const minRadius = 57;
    const maxRadius = 63;

    for (let i = 0; i < asteroidCount; i++) {
      const angle = Math.random() * Math.PI * 2;
      const radius = minRadius + Math.random() * (maxRadius - minRadius);
      const x = Math.cos(angle) * radius;
      const z = Math.sin(angle) * radius;
      const y = (Math.random() - 0.5) * 2;

      positions.push(x, y, z);
    }

    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
    return geometry;
  }, []);

  return (
    <points geometry={asteroids}>
      <pointsMaterial
        color="#8B7355"
        size={0.3}
        transparent
        opacity={0.6}
        sizeAttenuation={true}
      />
    </points>
  );
}
