import { useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { PlanetInfo } from "../data/planetData";
import Moon from "./Moon";
import PlanetLabel from "./PlanetLabel";
import { useSolarSystem } from "../lib/stores/useSolarSystem";

interface PlanetProps {
  planetData: PlanetInfo;
  isSelected: boolean;
  onSelect: () => void;
}

export default function Planet({ planetData, isSelected, onSelect }: PlanetProps) {
  const meshRef = useRef<THREE.Mesh>(null);
  const orbitRef = useRef<THREE.Group>(null);
  const ringRef = useRef<THREE.Mesh>(null);
  const { animationSpeed, isPaused, educationalMode } = useSolarSystem();

  useFrame((state, delta) => {
    if (isPaused) return;
    
    const adjustedDelta = delta * animationSpeed;
    
    // Orbital motion
    if (orbitRef.current) {
      orbitRef.current.rotation.y += adjustedDelta * planetData.orbitSpeed;
    }
    
    // Planet rotation
    if (meshRef.current) {
      meshRef.current.rotation.y += adjustedDelta * planetData.rotationSpeed;
    }

    // Animate selection ring
    if (ringRef.current && isSelected) {
      ringRef.current.rotation.x += adjustedDelta * 2;
      ringRef.current.rotation.z += adjustedDelta * 1.5;
    }
  });

  return (
    <group ref={orbitRef}>
      <group position={[planetData.distance, 0, 0]}>
        {/* Planet */}
        <mesh 
          ref={meshRef}
          onClick={(e) => {
            e.stopPropagation();
            onSelect();
          }}
          onPointerEnter={(e) => {
            document.body.style.cursor = 'pointer';
          }}
          onPointerLeave={(e) => {
            document.body.style.cursor = 'auto';
          }}
        >
          <sphereGeometry args={[planetData.size, 16, 16]} />
          <meshLambertMaterial 
            color={planetData.color}
            emissive={planetData.emissive || '#000000'}
            emissiveIntensity={planetData.emissive ? 0.1 : 0}
          />
        </mesh>

        {/* Selection ring */}
        {isSelected && (
          <mesh ref={ringRef}>
            <torusGeometry args={[planetData.size * 1.5, 0.1, 8, 32]} />
            <meshBasicMaterial color="#00ffff" />
          </mesh>
        )}

        {/* Orbit path */}
        <mesh rotation={[Math.PI / 2, 0, 0]}>
          <ringGeometry args={[planetData.distance - 0.05, planetData.distance + 0.05, 64]} />
          <meshBasicMaterial 
            color="#444444" 
            transparent 
            opacity={educationalMode ? 0.4 : 0.2} 
            side={THREE.DoubleSide}
          />
        </mesh>

        {/* Label in educational mode */}
        {educationalMode && (
          <PlanetLabel 
            name={planetData.name} 
            position={[0, planetData.size + 1, 0]} 
          />
        )}

        {/* Moons */}
        {planetData.moonList && planetData.moonList.map((moon, index) => (
          <Moon key={index} moonData={moon} />
        ))}
      </group>
    </group>
  );
}
